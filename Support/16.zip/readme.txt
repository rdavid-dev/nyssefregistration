admin login
/admin/index.php

email:admin@spammer.id
pass:bawok

please dont share. priv8