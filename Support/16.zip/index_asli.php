<?php
/* 16Shop - by devilscream */
include 'load.php';
valid_file("v2/index.php");
?>